# imx-uuc

A Daemon wait for mfgtools host's command

linuxrc: boot script to launch uuc deamon. 
